package testoviStanari;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.tesdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.ZgradeCreationPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.ZgradePregledPageKTS;

public class PostaviKorisnikaZaStanaraTest2 {

	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private ZgradeCreationPageKTS zgradeCreationPageKTS;
	private ZgradePregledPageKTS zgradePregledPageKTS;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();
		idiNaStranicuZgrade();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		zgradePregledPageKTS = new ZgradePregledPageKTS(driver);

		zgradeCreationPageKTS = new ZgradeCreationPageKTS(driver);
	}

	public void login() {

		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}

	// @BeforeTest
	public void idiNaStranicuZgrade() {
		menuPageKTS.getPocetna().isDisplayed();
		menuPageKTS.getNavBar().isDisplayed();
		menuPageKTS.getZgrade().isDisplayed();
		menuPageKTS.getZgrade().click();
		assertTrue(zgradeCreationPageKTS.getProzorZaDodavanjeZgrade().isDisplayed());
		zgradeCreationPageKTS.getMesto().isDisplayed();
		zgradeCreationPageKTS.getUlica().isDisplayed();
		zgradeCreationPageKTS.getBroj().isDisplayed();
		zgradeCreationPageKTS.getBrojStanova().isDisplayed();
		zgradeCreationPageKTS.getSubmitDodajteDugme().isDisplayed();
		zgradeCreationPageKTS.getResetujte().isDisplayed();

	}

	// POZITIVAN TEST
	@Test(priority = 1)
	public void dodavanjeZgrade() {
		zgradeCreationPageKTS.createZgrada("Sombor", "Petra Kocica", "2", "10");
		zgradeCreationPageKTS.getPorukaDodavanja();
		assertTrue(zgradeCreationPageKTS.getPorukaDodavanja().isDisplayed());
	}

	// POZITIVAN TEST
	@Test(priority = 2)
	public void proveriDodavanjeZgrade() {
		zgradeCreationPageKTS.getPregled().click();
		assertTrue(zgradePregledPageKTS.getTabelaZgradaPregled().isDisplayed());
		zgradePregledPageKTS.getRedPretrage().isDisplayed();
		assertTrue(zgradePregledPageKTS.getSelectPrikazi().isDisplayed());

		zgradePregledPageKTS.getPrikaz().selectByValue("50");
		zgradePregledPageKTS.isZgradaInTable("1");

	}

	// POZITIVAN TEST
	@Test(priority = 3)
	public void klikNaDodatuZgradu() {
		zgradePregledPageKTS.viewZgradaByAdresa("Petra Kocica 2, Sombor");
		zgradePregledPageKTS.getHoverTabelaZgrade().isDisplayed();
		zgradePregledPageKTS.viewVlasnikStanaZgrade("3");
		assertTrue(zgradePregledPageKTS.getTabelaKorisnici().isDisplayed());
	}

	// POZITIVAN TEST
	@Test(priority = 4)
	public void postavljanjeKorisnikaZaStanara() {
		zgradePregledPageKTS.pritisniDodajUstanareBtn("Marko Markovic");
		assertEquals(zgradePregledPageKTS.getPorukaDodatStanarUstan().getText(), "Uspesno ste dodali stanara!");
	}

	@AfterSuite
	public void closeSelenium() {
		driver.quit();
	}
}
