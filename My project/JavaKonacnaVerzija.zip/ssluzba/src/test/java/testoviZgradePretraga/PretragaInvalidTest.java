package testoviZgradePretraga;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.tesdevelopment.KTS.pages.global.HomePageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.ZgradeCreationPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.ZgradePregledPageKTS;

public class PretragaInvalidTest {

	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private HomePageKTS homePageKTS;
	private MenuPageKTS menuPageKTS;
	private ZgradeCreationPageKTS zgradeCreationPageKTS;
	private ZgradePregledPageKTS zgradePregledPageKTS;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		homePageKTS = new HomePageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		zgradeCreationPageKTS = new ZgradeCreationPageKTS(driver);
		zgradePregledPageKTS = new ZgradePregledPageKTS(driver);

	}

	public void login() {

		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}

	@Test
	public void zgradaNijePronadjena() {

		menuPageKTS.getPocetna().isDisplayed();
		assertTrue(menuPageKTS.getZgrade().isDisplayed());
		menuPageKTS.getNavBar().isDisplayed();

		menuPageKTS.getZgrade().click();
		zgradeCreationPageKTS.getPregled().click();
		zgradePregledPageKTS.getPretragaBtn().isDisplayed();

		zgradePregledPageKTS.pretragaZgrade("Sekspirova 1", "Novi Sad");
		zgradePregledPageKTS.getPretragaBtn().click();
		assertEquals(zgradePregledPageKTS.getMessageNotFound().getText(),
				"Nijedna zgrada sa trazenim kriterijumima nije prondajena!");

	}

	/*
	 * Ovo je poruka o greski, smatram da treba istestirati da li se prilikom
	 * unosenja nevalidnog podatka, pojavi neka poruka
	 */

	@AfterSuite
	public void closeSelenium() {
		driver.quit();

	}
}
