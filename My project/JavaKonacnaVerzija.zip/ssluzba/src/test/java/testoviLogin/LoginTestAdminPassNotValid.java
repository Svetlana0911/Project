package testoviLogin;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.tesdevelopment.KTS.pages.global.HomePageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.LoginPageKTS;

public class LoginTestAdminPassNotValid {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private HomePageKTS homePageKTS;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		homePageKTS = new HomePageKTS(driver);

	}
	// NEGATIVAN TEST

	@Test
	public void login() {

		loginPageKTS.login("admin@gmail.com", "123");

		String expectedMessage = "Lozinka nije validnog formata (Mora biti bar jedno veliko slovo, veliko malo slovo i broj i minimalne duzine 6)!";
		assertEquals(expectedMessage, homePageKTS.getNeuspesnoLogovanje());

	}

	@AfterSuite
	public void closeSelenium() {
		driver.quit();

	}

}
