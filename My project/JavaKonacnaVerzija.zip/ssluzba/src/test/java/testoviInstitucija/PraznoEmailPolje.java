package testoviInstitucija;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.tesdevelopment.KTS.pages.global.HomePageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.InstitucijaCreationPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.StanariCreationPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.ZgradeCreationPageKTS;
import rs.ac.uns.tesdevelopment.KTS.pages.global.ZgradePregledPageKTS;

public class PraznoEmailPolje {
	
	
	
	

	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private HomePageKTS homePageKTS;
	private MenuPageKTS menuPageKTS;
	private ZgradeCreationPageKTS zgradeCreationPageKTS;
	private ZgradePregledPageKTS zgradePregledPageKTS;
	private StanariCreationPageKTS stanariCreationPageKTS;
	private InstitucijaCreationPageKTS institucijaCreationPageKTS;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		homePageKTS = new HomePageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		zgradeCreationPageKTS = new ZgradeCreationPageKTS(driver);
		zgradePregledPageKTS = new ZgradePregledPageKTS(driver);
		stanariCreationPageKTS = new StanariCreationPageKTS(driver);
		institucijaCreationPageKTS = new InstitucijaCreationPageKTS(driver);
	}

	public void login() {

		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}
	@Test

	public void praznoEmailPolje() {

		menuPageKTS.getPocetna().isDisplayed();

		menuPageKTS.getNavBar().isDisplayed();
		
		institucijaCreationPageKTS.getInstitucije().click();
		institucijaCreationPageKTS.dodajInstituciju("", "Bar8slova", "Policija", "Novi Sad", "Cara Lazara", "45", "1122334455");
		institucijaCreationPageKTS.getPorukaPraznaEmailAdresa();
		assertEquals(institucijaCreationPageKTS.getPorukaPraznaEmailAdresa().getText(), "Ovo polje ne sme biti prazno!");



}
	@AfterSuite
	public void closeSelenium() {
		driver.quit();
}}
