package rs.ac.uns.tesdevelopment.KTS.pages.global;

import static org.testng.AssertJUnit.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class ZgradeCreationPageKTS {
	WebDriver driver;

	public ZgradeCreationPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public WebElement getProzorZaDodavanjeZgrade () {
//return Utils.waitForElementPresence(driver, By.xpath("//div[@class=\"container\"]//form[@class=\"col-md-6 box ng-untouched ng-pristine ng-invalid\"]"), 0);
		return Utils.waitForElementPresence(driver, By.xpath("/html/body/app-root/app-zgrade/div/app-dodaj-zgradu/div/form"), 10);
	}
	
	public WebElement getDodavanje(){
		return Utils.waitToBeClickable(driver, By.xpath("//div/ul/li/button[@class=\"btn btn-outline-primary\"]"), 10);
	}
	public WebElement getFormaDodavanjaZgrade (){
		return Utils.waitForElementPresence(driver, By.className("col-md-6 box ng-pristine ng-invalid ng-touched"), 10);
	
	}

	public WebElement getPregled(){
		return Utils.waitForElementPresence(driver, By.xpath("//div/ul/li/button[@class=\"btn btn-outline-primary\"]"), 10);
	}
	public WebElement getMesto(){
		return Utils.waitForElementPresence(driver, By.id("mesto"), 20);
	}

	public void setMesto (String mesto) {
		WebElement mestoInput = getMesto();
		mestoInput.clear();
		mestoInput.sendKeys(mesto);
}
	

	public WebElement getUlica(){
		return Utils.waitForElementPresence(driver, By.name("ulica"), 20);






}
	public void setUlica (String ulica) {
		WebElement ulicaInput = getUlica();
		ulicaInput.clear();
		ulicaInput.sendKeys(ulica);
	
	}
	public WebElement getBroj(){
		return Utils.waitForElementPresence(driver, By.name("broj"), 10);
}
	public void setBroj (String broj) {
		WebElement brojInput = getBroj();
		brojInput.clear();
		brojInput.sendKeys(broj);	
}
	public WebElement getBrojStanova(){
		return Utils.waitForElementPresence(driver, By.name("brojStanova"), 10);	

}
	
	public void setBrojStanova (String brojStanova) {
		WebElement brojStanovaInput = getBrojStanova();
		brojStanovaInput.clear();
		brojStanovaInput.sendKeys(brojStanova);

}
	
	public WebElement getSubmitDodajteDugme(){

		return Utils.waitForElementPresence(driver, By.xpath("//div//button[@type=\"submit\"]"), 10);
}
	public WebElement getDisabledDodajteDugme(){
		return Utils.waitForElementPresence(driver, By.xpath("//div//button[contains(text(),'Dodajte')]"), 20);
}
	public WebElement getResetujte(){
		//return Utils.waitForElementPresence(driver, By.xpath("//div//button[@class='btn-danger']"), 10);
return Utils.waitForElementPresence(driver, By.className("btn-danger"), 10);
}
	
	
	//public String getPorukaDodavanja() {
		//return Utils.waitForElementPresence(driver,By.xpath("//*[contains(text)(), 'Uspesno ste dodali zgradu!']") , 10).getText();
	public WebElement getPorukaDodavanja(){
		return Utils.waitForElementPresence(driver, By.id("toast-container"),20);
}
	public WebElement getZgradaPostojiPoruka(){
		//return Utils.waitForElementPresence(driver, By.xpath("//*[@id=\"toast-container\"]/div"),20);
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label]"),20);
}
	public WebElement getPorukaPraznoPolje (){

return Utils.waitForElementPresence(driver, By.xpath("//div[1]/div/div[contains(text(), 'Ovo polje ne sme biti prazno')]"), 10);
	}
	public WebElement getPorukaBrojMoraBitiPozitivan () {
		return Utils.waitForElementPresence(driver,By.xpath("//div[3]/div/div[contains(text(), 'Broj mora biti pozitivan')]"), 10);
	}
	public void createZgrada(String mesto, String ulica, String broj, String brojStanova){
		setMesto(mesto);
		setUlica(ulica);
		setBroj(broj);
		setBrojStanova(brojStanova);
		getSubmitDodajteDugme().click();	
}}








