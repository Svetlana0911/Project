package rs.ac.uns.testdevelopment.ssluzba.pages.global;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class MenuPage1 {
	private WebDriver driver;

	public MenuPage1(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public WebElement getAccountMenu() {
		return Utils.waitForElementPresence(driver, By.id("account-menu"), 10);
	}
	
	public WebElement getSignUp(){
		return Utils.waitForElementPresence(driver, By.xpath("a[@ui-sref='login']"), 10);
	}
	//Zasto tu ide: Utils.waitToBeClickable?
	public WebElement getEntities(){
		return Utils.waitToBeClickable(driver, By.className("Entities"), 10);
	}
	
	public WebElement  getStudentsLink(){
		return Utils.waitForElementPresence(driver, By.xpath("//a[@ui-sref='studenti']"), 10);
	}
	
	
	
	
	
	
	
	
	
	

}
