package rs.ac.uns.tesdevelopment.KTS.pages.global;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.testng.annotations.AfterSuite;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class ZgradePregledPageKTS {
	WebDriver driver;

	public ZgradePregledPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
//	public WebElement getFilterPrikaz(){
	//	return Utils.waitForElementPresence(driver, By.id("prikaz"), 10);
	public WebElement getRedPretrage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@class='row']"), 20);
	
	

}
	public WebElement getSelectPrikazi() {
		return Utils.waitForElementPresence(driver, By.id("prikaz"), 20);
}

	public Select getPrikaz(){
		WebElement el = driver.findElement(By.id("prikaz"));
		Select dropdown = new Select(el);
		return dropdown;
	
}
	public void setPrikaz(String pr){
		Select prikaz = this.getPrikaz();
		prikaz.selectByValue(pr);
	
}
public WebElement getUlicaBroj ()	{
	return Utils.waitForElementPresence(driver, By.id("ulicaBroj"), 10);

}
public void setUlicaBroj (String ulicaBroj) {
	WebElement ulicaBrojInput = getUlicaBroj();
	ulicaBrojInput.clear();
	ulicaBrojInput.sendKeys(ulicaBroj);
}
public WebElement getGrad (){
	return Utils.waitForElementPresence(driver, By.id("mesto"), 10);
}


public void setGrad (String grad){
	WebElement gradInput = getGrad();
	gradInput.clear();
	gradInput.sendKeys(grad);
}

public WebElement getPretragaBtn (){

	return Utils.waitForElementPresence(driver, By.xpath("//div/button[contains(text(),'Pretraga')]"), 10);
}



public WebElement getMessageNotFound (){

	return Utils.waitForElementPresence(driver, By.tagName("h2"), 20);
}

public WebElement getTabelaZgradaPregled () {
	return Utils.waitForElementPresence(driver, By.tagName("table"), 10);
	
	
}
public List<WebElement> getTabelaRedovi () {
	return this.getTabelaZgradaPregled().findElements(By.tagName("tr"));
}

public boolean isZgradaInTable (String adresa) {
	return Utils.isPresent(driver, By.xpath("//*[contains(text(),\"" + adresa + "\")]/../.."));
	
}

public WebElement getZgradaRedByAdress (String adresa) {
	return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + adresa + "\")]/../.."), 10);
	
}

public void viewZgradaByAdresa(String adresa){
	getZgradaRedByAdress(adresa).findElement(By.tagName("a")).click();
	
}
public WebElement getHoverTabelaZgrade() {
	return Utils.waitForElementPresence(driver, By.xpath("//*[@class='table table-hover']"), 10);
}
public WebElement getVlasnikaStanaZgrade(String vlasnik) {
	return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + vlasnik + "\")]/../.."), 10);
}
public void viewVlasnikStanaZgrade(String vlasnik) {
	getVlasnikaStanaZgrade(vlasnik).findElement(By.linkText("Vlasnik i stanari")).click();
}
public WebElement getTabelaKorisnici() {
	return Utils.waitForElementPresence(driver, By.id("korisnici"), 20);

}
public WebElement getRowKorisniciByStanar(String korisnik) {
	return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + korisnik + "\")]/../.."), 10);
}
public WebElement getPorukaDodatStanarUstan() {
	return Utils.waitForElementPresence(driver, By.xpath("//*[@aria-label='Uspesno ste dodali stanara!']"), 20);
}
public void pritisniDodajUstanareBtn(String korisnik) {
	getRowKorisniciByStanar(korisnik).findElement(By.xpath("//button[contains(text(),'Dodaj u stanare')]")).click();

}
public WebElement getTabelaStanari() {
	return Utils.waitForElementPresence(driver, By.id("stanari"), 20);
}
public WebElement getRowVlasniciStanari(String stanar) {
	return Utils.waitForElementPresence(driver, By.tagName("tr"), 10);

}
public void pritisniPostaviZaVlasnikaBtn(String stanar) {
	getRowVlasniciStanari(stanar).findElement(By.xpath("//button[contains(text(),'Postavi za vlasnika')]")).click();
}
public void ukloniStanaraBtn(String stanar){
	getRowVlasniciStanari(stanar).findElement(By.xpath("//button[contains(text(),'Ukloni')]")).click();
}

public WebElement getPorukaUspesnoPostavljenVlasnik() {
	return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste postavili vlasnika!']"),
			10);
	
}

	public WebElement getUkloniVlasnikaBtn() {
		return Utils.waitForElementPresence(driver, By.id("ukloniVlasnika"), 40);
	}

	public WebElement getPorukaUklonjenVlasnik() {
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste uklonili vlasnika!']"),
				20);
	}
	
	public WebElement getPorukaUklonjenStanar(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste uklonili stanara!']"), 20);
	}
	public void pritisniPostaviZaPredsednikaBtn(String stanar){
		getRowVlasniciStanari(stanar).findElement(By.xpath("//button[contains(text(),'Postavi za predsednika')]")).click();
	}
	public WebElement getPostaviZaPredsednikaBtn(){
		return Utils.waitToBeClickable(driver, By.xpath("//button[contains(text(),'Postavi za predsednika')]"), 10);
	}
	
	public WebElement getPorukaUspesnoPostavljenPredsednik(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste postavili predsednika zgrade!']"), 20);
	
	
	
	
}
public void pretragaZgrade(String ulicaBroj, String grad){
	setUlicaBroj(ulicaBroj);
	setGrad(grad);
	getPretragaBtn().click();
	
	
	
	
	
	




















}


@AfterSuite
public void closeSelenium(){
	driver.quit();
}}
