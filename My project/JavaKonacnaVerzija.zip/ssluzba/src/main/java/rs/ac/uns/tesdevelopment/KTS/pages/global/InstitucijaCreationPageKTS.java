package rs.ac.uns.tesdevelopment.KTS.pages.global;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class InstitucijaCreationPageKTS {
	
	WebDriver driver;

	public InstitucijaCreationPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public WebElement getInstitucije(){
		return Utils.waitForElementPresence(driver,By.linkText("Institucije"), 10);

}
	public WebElement 	getRegistracija () {

		 return Utils.waitForElementPresence(driver, By.xpath("//button[contains(text(),'Registracija')]"), 20);

}
	
	public WebElement getEmail () {
		return Utils.waitForElementPresence(driver, By.id("email"), 10);
		
	}
	public void setEmail (String email) {
		WebElement emailInput = getEmail();
	emailInput.clear();
		emailInput.sendKeys(email);
}
	public WebElement getLozinka () {
		return Utils.waitForElementPresence(driver, By.id("lozinka"), 10);

}
	public void setLozinka (String lozinka) {
		WebElement lozinkaInput = getLozinka();
	lozinkaInput.clear();
		lozinkaInput.sendKeys(lozinka);	
}
	
	public WebElement getNaziv () {
		return Utils.waitForElementPresence(driver, By.id("naziv"), 10);
}
	public void setNaziv (String naziv) {
		WebElement nazivInput = getNaziv();
	nazivInput.clear();
		nazivInput.sendKeys(naziv);		
}
	public WebElement getMesto () {
		return Utils.waitForElementPresence(driver, By.id("mesto"), 10);
}
	public void setMesto (String mesto) {
		WebElement mestoInput = getMesto();
	mestoInput.clear();
		mestoInput.sendKeys(mesto);			

}
	public WebElement getUlica () {
		return Utils.waitForElementPresence(driver, By.id("ulica"), 10);
}
	
	public void setUlica (String ulica) {
		WebElement ulicaInput = getUlica();
	ulicaInput.clear();
		ulicaInput.sendKeys(ulica);	
}
	public WebElement getBroj () {
		return Utils.waitForElementPresence(driver, By.id("broj"), 10);

}
	public void setBroj (String broj) {
		WebElement brojInput = getBroj();
	brojInput.clear();
		brojInput.sendKeys(broj);	

}
	public WebElement getBrojTelefona () {
		return Utils.waitForElementPresence(driver, By.id("brojTelefona"), 10);	

}
	
	public void setBrojTelefona (String brojTelefona) {
		WebElement brojTelefonaInput = getBrojTelefona();
	brojTelefonaInput.clear();
		brojTelefonaInput.sendKeys(brojTelefona);	
}
	public WebElement  getRegistrujteBtn (){
		return Utils.waitForElementPresence(driver, By.xpath("//button[@type='submit']"), 10);
}
	
	public WebElement getProzorDodavanja () {
		return Utils.waitForElementPresence(driver, By.className("col-md-6"), 10);
		
	}
	public WebElement getPorukaUspesnostiRegistracije () {
		
		return Utils.waitForElementPresence(driver, By.xpath("//div[@role='alertdialog']"), 10);
	
}
	public WebElement getPregledInstitucija (){
		return Utils.waitForElementPresence(driver, By.xpath("/html/body/app-root/app-institucije/div/div/div/div/ul/li[2]/button/b"), 10);
	
}
	public WebElement getTabelaInstitucija () {
		return Utils.waitForElementPresence(driver, By.tagName("table"), 10);
		
}
	public List<WebElement> getTabelaRedovi() {
		return this.getTabelaInstitucija().findElements(By.tagName("tr"));
	}	
	public boolean isInstitucijaInTabela(String naziv) {
		return Utils.isPresent(driver, By.xpath("//*[contains(text(),\"" + naziv + "\")]/../.."));
	}
	public WebElement getInstitucijaRedByNaziv(String naziv){
		return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + naziv + "\")]/../.."), 10);	
	}
	public void viewInstitucijaByNaziv(String naziv){
		getInstitucijaRedByNaziv(naziv).findElement(By.tagName("a")).click();
}
	public WebElement getPorukaNeispravnaEmailAdresa (){
		
		return Utils.waitForElementPresence(driver, By.xpath("//div[1]/div/div[contains(text(), 'Neispravna email adresa!')]"), 10);
}
	public WebElement getPorukaPraznaEmailAdresa (){
		return Utils.waitForElementPresence(driver, By.xpath("//div[1]/div/div[contains(text(), 'Ovo polje ne sme biti prazno!')]"), 10);
}
	public WebElement getNeispravnaLozinka () {
		return Utils.waitForElementPresence(driver, By.xpath("//div[2]/div/div[contains(text(), 'Neispravna lozinka!')]"), 10);
}
	public WebElement getPraznaLozinka () {
		return Utils.waitForElementPresence(driver, By.xpath("//div[2]/div/div[contains(text(), 'Ovo polje ne sme biti prazno!')]"), 10);
}
	public void dodajInstituciju(String email, String lozinka, String naziv, String mesto, String ulica, String broj, String brojTelefona){
		setEmail(email);
		setLozinka(lozinka);
		setNaziv(naziv);
		setMesto(mesto);
		setUlica(ulica);
		setBroj(broj);
		setBrojTelefona(brojTelefona);
		
	
		getRegistrujteBtn().click();

}}
