package rs.ac.uns.tesdevelopment.KTS.pages.global;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class ZgradaListPageKTS {
	
	private WebDriver driver;


	public ZgradaListPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}

	
	
	
	public WebElement getTabelaPregledZgrada(){
		return Utils.waitForElementPresence(driver, By.xpath("//table[@class=\"table table-hover\"]"), 10);
	
	}
	public List<WebElement> getTabelaRedovi() {
	
	
		return this.getTabelaPregledZgrada().findElements(By.tagName("tr"));
	}
	
	public boolean isZgradaInTabela(String ulica) {
		return Utils.isPresent(driver, By.xpath("//*[contains(text(),\"" + ulica + "\")]/../.."));
	}
	
	public WebElement getZgradaRedByAdresa(String ulica){
		return Utils.waitForElementPresence(driver, By.xpath(""), 10);
		
	}
	

}



