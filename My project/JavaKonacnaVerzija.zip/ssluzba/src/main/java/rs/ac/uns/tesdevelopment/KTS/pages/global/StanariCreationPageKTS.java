package rs.ac.uns.tesdevelopment.KTS.pages.global;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class StanariCreationPageKTS {
	WebDriver driver;

	public StanariCreationPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public WebElement getStanari(){
		return Utils.waitForElementPresence(driver,By.linkText("Stanari"), 10);

}
public WebElement 	getRegistracija () {
	//return Utils.waitForElementPresence(driver, By.xpath("/html/body/app-root/app-stanari/div/div/div/div/ul/li[1]/button/b"), 10);
	 return Utils.waitForElementPresence(driver, By.xpath("//button[contains(text(),'Registrujte')]"), 20);
}
public WebElement getDisabledRegistrujteBtn(){
	 return Utils.waitForElementPresence(driver, By.xpath("*//div/div/button[@disabled]"), 20);
}
public WebElement getEmail () {
	return Utils.waitForElementPresence(driver, By.id("email"), 10);
}
public void setEmail (String email) {
	WebElement emailInput = getEmail();
emailInput.clear();
	emailInput.sendKeys(email);
}

public WebElement getLozinka () {
	return Utils.waitForElementPresence(driver, By.id("lozinka"), 10);

}

public void setLozinka (String lozinka) {
	WebElement lozinkaInput = getLozinka();
lozinkaInput.clear();
	lozinkaInput.sendKeys(lozinka);


}

public WebElement getIme () {
	return Utils.waitForElementPresence(driver, By.id("ime"), 10);
}
public void setIme (String ime) {
	WebElement imeInput = getIme();
imeInput.clear();
	imeInput.sendKeys(ime);

}
public WebElement getPrezime () {
	return Utils.waitForElementPresence(driver, By.id("prezime"), 10);
}
public void setPrezime (String prezime) {
	WebElement prezimeInput = getPrezime();
prezimeInput.clear();
	prezimeInput.sendKeys(prezime);

}
public WebElement  getRegistrujteBtn (){
	return Utils.waitForElementPresence(driver, By.xpath("//button[@type='submit']"), 10);
}
public WebElement getProzorDodavanja () {
	return Utils.waitForElementPresence(driver, By.className("col-md-6"), 10);
	
	
}
public WebElement getPorukaUspesnostiRegistracije () {
	
return Utils.waitForElementPresence(driver, By.xpath("//div[@role='alertdialog']"), 10);


}
public WebElement getPorukaNeispravnaEmailAdresa (){
	return Utils.waitForElementPresence(driver, By.xpath("//div[1]/div/div[contains(text(), 'Neispravna email adresa!')]"), 10);
	
	
	
	
	
	
	
	
	
	
	
	
	

}
public WebElement getPorukaPraznaEmailAdresa (){
	return Utils.waitForElementPresence(driver, By.xpath("//div[1]/div/div[contains(text(), 'Ovo polje ne sme biti prazno!')]"), 10);
}
	public WebElement getNeispravnaLozinka () {
		return Utils.waitForElementPresence(driver, By.xpath("//div[2]/div/div[contains(text(), 'Neispravna lozinka!')]"), 10);
	}
		public WebElement getPraznaLozinka () {
			return Utils.waitForElementPresence(driver, By.xpath("//div[2]/div/div[contains(text(), 'Ovo polje ne sme biti prazno!')]"), 10);
		}
		
		public WebElement getPorukaGreskeRegistracije (){
			return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-live='polite']"), 10);
			//return Utils.waitForElementPresence(driver, By.className("ng-star-inserted"), 10);
		}
		public WebElement getResetujteBtn (){
			return Utils.waitForElementPresence(driver, By.className("btn-danger"), 10);
		}
		public WebElement getPregledStanari () {
			return Utils.waitForElementPresence(driver, By.xpath("/html/body/app-root/app-stanari/div/div/div/div/ul/li[2]/button"), 10);
		}
			public WebElement getPretragaStanariBtn () {
				return Utils.waitForElementPresence(driver, By.xpath("/html/body/app-root/app-stanari/div/app-izlistaj-stanare/div/div[1]/div/button"), 10);
				

			}
			
			public WebElement getFilterPretrage () {
				return Utils.waitForElementPresence(driver, By.id("filter"), 10);
}
			
			public void setFilterPretrage (String filterPretrage) {
				WebElement filterPretrageInput = getFilterPretrage();
			filterPretrageInput.clear();
				filterPretrageInput.sendKeys(filterPretrage);
			
			}	
			
			public WebElement getPorukaNeuspesnaPretraga () {

				return Utils.waitForElementPresence(driver, By.tagName("h2"), 10);
			}
			

			//public WebElement getTabelaStanari () {
				//return Utils.waitForElementPresence(driver, By.tagName("tabela"), 10);
			//}
	///////////////		//////////////////////////////////////////////////////////////////////////
			public WebElement getRedZaPretragu(){
				return Utils.waitForElementPresence(driver, By.xpath("//div[@class='row']"), 20);
				
			
}
//			public void setPrikaz(String pr){
//				Select prikaz = this.getPrikaz();
//				prikaz.selectByValue(pr);
//}
		
			public Select getPrikaz(){
			WebElement el = driver.findElement(By.id("prikaz"));
				Select dropdown = new Select(el);
				return dropdown;
			}
			public WebElement getSelectPrikazi(){
				return Utils.waitForElementPresence(driver, By.id("prikaz"), 20);
}
			public WebElement getTabelaStanari () {
				return Utils.waitForElementPresence(driver, By.tagName("table"), 10);
}
			public List<WebElement> getTabelaRedovi() {
				return this.getTabelaStanari().findElements(By.tagName("tr"));
			}	
			public boolean isStanarInTabela(String imePrezime) {
				return Utils.isPresent(driver, By.xpath("//*[contains(text(),\"" + imePrezime + "\")]/../.."));
			}
			public WebElement getStanarRedByImePrezime(String imePrezime){
				return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + imePrezime + "\")]/../.."), 10);	
			}
			public void viewStanarByImePrezime(String imePrezime){
				getStanarRedByImePrezime(imePrezime).findElement(By.tagName("a")).click();
}
	
public void dodajStanara(String email, String lozinka, String ime, String prezime){
	setEmail(email);
	setLozinka(lozinka);
	setIme(ime);
setPrezime(prezime);
	getRegistrujteBtn().click();
}



}













