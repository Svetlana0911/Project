package rs.ac.uns.tesdevelopment.KTS.pages.global;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class MenuPageKTS {
	
	WebDriver driver;

	public MenuPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public WebElement getIzlogujteSe () {
		return Utils.waitToBeClickable(driver, By.className("btn-secondary"), 10);
	
}
	public WebElement getPregledBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//button/b[contains(text(),\"Pregled\")]"), 20);
}
	
	public WebElement getDodavanjeBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("/html/body/app-root/app-zgrade/div/div/div/div/ul/li[1]/button"), 20);
}
	public WebElement getNavBar() {
		return Utils.waitForElementPresence(driver, By.tagName("nav"), 50);	
}
	public WebElement getPocetna () {
		return Utils.waitToBeClickable(driver, By.linkText("Pocetna"), 10);
	}
	
	
	
	
	
	
	
	
	
	
	public WebElement getZgrade () {
		return Utils.waitForElementPresence(driver, By.xpath("//a[@href='/zgrade']"), 50);
		//return Utils.waitToBeClickable(driver, By.linkText("Zgrade"), 10);
		
	}
	public WebElement getStanari () {
		return Utils.waitToBeClickable(driver, By.linkText("Stanari"), 10);
	
	}
	public WebElement getLabelEmail () {
		return Utils.waitForElementPresence(driver, By.xpath("//label[@class='nav-link active']"), 10);
	}
	}













