package rs.ac.uns.testdevelopment.ssluzba.pages.global;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class HomePage1 {
	
	private WebDriver driver;

	public HomePage1(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public String getLoginConfirmationText() {
		return Utils.waitForElementPresence(driver, By.xpath("//div [@translate=\"main.logged.message\"]"), 10).getText();
		
	}
	public Boolean getInitialMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@id=\"navbar-collapse\"]"), 10).isDisplayed();
	}
	
		
	}
	


