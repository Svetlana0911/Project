var LoginPageKTS = require('../pages/global.KTS/login.pageKTS.js');
var MenuPageKTS = require('../pages/global.KTS/menu.pageKTS.js');
var HomePageKTS = require('../pages/global.KTS/home.pageKTS.js');
var StanariCreatePageKTS = require('../pages/global.KTS/stanari.pageKTS.js');
var utils = require('../pages/utils.js');
var baseUrl = 'http://localhost:8080/logovanje';

describe('Registracija stanara od strane admina', function () {
    var loginPageKTS,
        menuPageKTS,
        homePageKTS,
        stanariCreatePageKTS;

    beforeAll(function () {
        browser.ignoreSynchronization = true;
        loginPageKTS = new LoginPageKTS();
        menuPageKTS = new MenuPageKTS();
        homePageKTS = new HomePageKTS();
        stanariCreatePageKTS = new StanariCreatePageKTS();
        browser.get('/');
        // expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/logovanje');
    });

    it('should succesfully register stanara', function () {
        loginPageKTS.login('admin@gmail.com', 'Bar5slova');
        expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/pocetna');

        expect(menuPageKTS.pocetna.isDisplayed()).toBe(true);

        menuPageKTS.stanari.click();

        expect(stanariCreatePageKTS.formRegistracijaStanara.isDisplayed()).toBe(true);
        stanariCreatePageKTS.createStanar('jana5@gmail.com', 'Dar1slova', 'Ira', 'Iric');
        expect(stanariCreatePageKTS.uspesnaRegistracijaPoruka).toBe(true);
        menuPageKTS.izlogujteSeBtn.click();

    });
    
});