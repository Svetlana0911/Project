


var LoginPageKTS = require('../pages/global.KTS/login.pageKTS.js');
var MenuPageKTS = require('../pages/global.KTS/menu.pageKTS.js');
var HomePageKTS = require('../pages/global.KTS/home.pageKTS.js')
var utils = require('../pages/utils.js');
var baseUrl = 'http://localhost:8080/logovanje';

describe('Logovanje', function () {
    var loginPageKTS,
        menuPageKTS,
        homePageKTS;

    beforeAll(function () {
        browser.ignoreSynchronization = true;
        loginPageKTS = new LoginPageKTS();
        menuPageKTS = new MenuPageKTS();
        homePageKTS = new HomePageKTS();
        browser.get('/');
        expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/logovanje');
    });
    it('nevalidno logovanje as "admin"', function () {
       
      
        loginPageKTS.login('admin@gmail.com', '123');
       
       
        var expectedMessage = "Lozinka nije validnog formata (Mora biti bar jedno veliko slovo, veliko malo slovo i broj i minimalne duzine 6)!";
       expect(expectedMessage).toEqual(homePageKTS.NeuspesnoLogovanjeText);
    });

    

    });