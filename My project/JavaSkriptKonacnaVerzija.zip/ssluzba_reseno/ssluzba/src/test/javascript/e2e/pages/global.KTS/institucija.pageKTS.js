
var InstitucijaPageKTS = function () { };
var utils = require('../utils.js');

InstitucijaPageKTS.prototype = Object.create({}, {

    institucija: {
        get: function () {
            return utils.waitForElementPresence(by.linkText('Institucije'), 10000);
        }

    },
    registracija: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//button[contains(text(),'Registracija')]"), 10000);
    
        }
    },
    emailPolje: {
        get function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="email"]'), 10000);
        },
        set: function (value) {
            return this.emailPolje.clear().sendKeys(value);

        }
    },
    lozinkaPolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="lozinka"]'), 10000);
        },
        set: function (value) {
            return this.lozinkaPolje.clear().sendKeys(value);
        }

    },
    nazivPolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="naziv"]'), 10000);
        },
        set: function (value) {
            return this.nazivPolje.clear().sendKeys(value);
        }
    },
    mestoPolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="prezime"]'), 10000);

        },
        set: function (value) {
            return this.mestoPolje.clear().sendKeys(value);
        }

    },


    ulicaPolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="ulica"]'), 10000);

        },
        set: function (value) {
            return this.ulicaPolje.clear().sendKeys(value);
        }

    },

    brojPolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="broj"]'), 10000);

        },
        set: function (value) {
            return this.brojPolje.clear().sendKeys(value);
        }

    },

    brojTelefona: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="brojTelefona"]'), 10000);

        },
        set: function (value) {
            return this.brojTelefona.clear().sendKeys(value);
        }

    },
    
    registrujteBtn: {
        get : function(){
            return utils.waitForElementPresence(by.xpath("//button[contains(text(),'Registrujte')]"),10000);
        }
    },
    createStanar:{
        value: function(emailString,lozinkaString,nazivString,mestoString,ulicaString,brojString,brojTelefonaString){
            this.emailPolje = emailString;
            this.lozinkaPolje = lozinkaString;
            this.nazivPolje = nazivString;
            this.mestoPolje = mestoString;
            this.ulicaPolje = ulicaString;
            this.brojPolje = brojString;
            this.brojTelefona = brojTelefonaString;
          
            this.registrujteBtn.click();
        
    

  
        }
    }

});
module.exports = InstitucijaPageKTS;