

var HomePageKTS = function() {}
var utils = require('../utils.js');

HomePageKTS.prototype = Object.create({}, {
    
   
    NeuspesnoLogovanjeText: {
        get: function() {
            return utils.waitForElementPresence(by.className('alert-dismissible'), 10000).getText();
        }
    }
});

module.exports = HomePageKTS;