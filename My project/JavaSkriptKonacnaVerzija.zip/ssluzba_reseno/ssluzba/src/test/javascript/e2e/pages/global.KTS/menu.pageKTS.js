var MenuPageKTS = function() {};
var utils = require('../utils.js');

MenuPageKTS.prototype = Object.create({},{
    pregledDugme:{
        get: function() {
            return utils.waitForElementPresence(by.xpath('//button/b[contains(text(),"Pregled")]'), 10000);
        }
    },
    dodavanjeDugme:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//button/b[contains(text(),"Dodavanje")]'),10000);
        }
    },

    pocetna:{
        get: function(){
            return utils.waitForElementPresence(by.linkText('Pocetna'),10000);
        }

    },
    zgrade:{
        get: function(){
            return utils.waitForElementPresence(by.linkText('Zgrade'),10000);
        }
    },
    stanari:{
        get: function(){
            return utils.waitForElementPresence(by.linkText('Stanari'),10000);
        }
    },
    labelMail:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//label[@class="nav-link active"]'),10000);
        }
    },
    izlogujteSeBtn:{
        get: function(){
            return utils.waitForElementPresence(by.className('btn-secondary'),10000);
        }
    },

});
module.exports = MenuPageKTS;
