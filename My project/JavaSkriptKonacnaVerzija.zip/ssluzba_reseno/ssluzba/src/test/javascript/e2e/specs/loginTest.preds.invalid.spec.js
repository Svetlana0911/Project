


var LoginPageKTS = require('../pages/global.KTS/login.pageKTS.js');
var MenuPageKTS = require('../pages/global.KTS/menu.pageKTS.js');
var HomePageKTS = require('../pages/global.KTS/home.pageKTS.js')
var utils = require('../pages/utils.js');
var baseUrl = 'http://localhost:8080/logovanje';

describe('Logovanje', function () {
    var loginPageKTS,
        menuPageKTS,
        homePageKTS;

    beforeAll(function () {
        browser.ignoreSynchronization = true;
        loginPageKTS = new LoginPageKTS();
        menuPageKTS = new MenuPageKTS();
        homePageKTS = new HomePageKTS();
        browser.get('/');
        expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/logovanje');
    });
    it('nevalidno logovanje za "predsednik"', function () {
       
      
        loginPageKTS.login('Skup@gmail.com', 'Bar5slova');
       
       
        var expectedMessage = "Pogresan email ili lozinka!";
       expect(expectedMessage).toEqual(homePageKTS.NeuspesnoLogovanjeText);
    });

    

    });