var Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
var SpecReporter = require('jasmine-spec-reporter');

exports.config = {
    seleniumServerJar: '../../../node_modules/protractor/selenium/selenium-server-standalone-2.47.1.jar',
    chromeDriver: '../../../chromedriver',
    allScriptsTimeout: 60000,

    specs: [
        'e2e/specs/adminInst.registracija.spec.js',

       // 'e2e/specs/adminStanar.registracija.spec.js',

      //  'e2e/specs/loginTest.admin.invalid.spec.js',
       // 'e2e/specs/loginTest.invalid.spec.js',
// 'e2e/specs/loginTest.preds.invalid.spec.js',

       // 'e2e/specs/loginTest.preds.valid.spec.js',
        //'e2e/specs/loginTest.stanar.valid.spec.js',
       'e2e/specs/loginTest.admin.valid.spec.js',
        //'e2e/specs/zadatak1.spec.js',
        //'e2e/specs/zadatak2.spec.js',
        //'e2e/specs/zadatak3.spec.js',
    ],

    capabilities: {
        'browserName': 'chrome',
    },

    directConnect: true,

    baseUrl: 'http://localhost:8080/logovanje',

    framework: 'jasmine2',

    jasmineNodeOpts: {
        showColors: true,
        isVerbose: true,
        defaultTimeoutInterval: 60000,
        print: function() {}
    },

    onPrepare: function() {
        // Postavljamo prozor na fullscreen
        browser.driver.manage().window().maximize();
        
        // Registrujemo reportere
        jasmine.getEnv().addReporter(new Jasmine2HtmlReporter({
            savePath: "./target/reports/e2e/",
            takeScreenshots: true,
            takeScreenshotsOnlyOnFailures: true,
            fixedScreenshotName: true
        }));
        jasmine.getEnv().addReporter(new SpecReporter({
            displayStacktrace: 'all',
            displaySpecDuration: true, 
            displayFailuresSummary: false, 
            displayPendingSummary: false,  
        }));
    }
};
