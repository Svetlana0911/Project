var FormPage = function() {};

FormPage.prototype = Object.create({}, {
  
});
